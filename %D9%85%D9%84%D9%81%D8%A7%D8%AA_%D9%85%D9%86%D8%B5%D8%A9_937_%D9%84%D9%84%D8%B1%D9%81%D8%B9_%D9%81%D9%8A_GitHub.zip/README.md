# منصة تحسين تجربة المريض 937 - نسخة تجريبية

هذا المستودع يحتوي ملفات برنامج تجريبي فقط، لا يحتوي سجلات مرضى حقيقية.

للنشر على Render: Node web service, build command `npm install`, start command `npm start`.
يحتاج إلى PostgreSQL ومتغيرات `DATABASE_URL`, `SESSION_SECRET`, `ADMIN_PASSWORD`, `VIEWER_PASSWORD`.
لن تعمل المزامنة المستمرة بدون قاعدة البيانات.
لا تستخدم هذه النسخة لاستقبال بيانات مرضى بدون اعتماد أمن المعلومات.
