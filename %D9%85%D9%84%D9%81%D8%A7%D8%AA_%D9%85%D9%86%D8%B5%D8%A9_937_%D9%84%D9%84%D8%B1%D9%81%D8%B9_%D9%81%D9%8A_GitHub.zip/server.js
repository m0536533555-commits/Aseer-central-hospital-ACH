'use strict';
/** Prototype only. Never use for real patient-level health data or as a production EHR system. */
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {URL}=require('node:url');

const host='0.0.0.0',port=Number(process.env.PORT||3000);
const sessionSecret=process.env.SESSION_SECRET||'';
const adminPassword=process.env.ADMIN_PASSWORD||'';
const viewerPassword=process.env.VIEWER_PASSWORD||'';
const inMemory=(process.env.DEMO_MEMORY_MODE==='true' && process.env.NODE_ENV!=='production');
const conn=process.env.DATABASE_URL||'';
if(sessionSecret.length<32 || adminPassword.length<12 || viewerPassword.length<12 || adminPassword===viewerPassword){
 console.error('Set SESSION_SECRET (>=32 chars), distinct ADMIN_PASSWORD and VIEWER_PASSWORD (>=12 chars).');process.exit(1);
}
if(!conn&&!inMemory){console.error('DATABASE_URL (Render Postgres) is required. Demo memory mode is for local testing only.');process.exit(1)}
const pg=inMemory?null:require('pg');
const pool=pg?new pg.Pool({connectionString:conn,ssl:{rejectUnauthorized:false},max:3}):null;
const publicDir=__dirname;
const initial=JSON.parse(fs.readFileSync(path.join(__dirname,'initial.json'),'utf8'));
let current={revision:1,snapshot:initial};
const loginFailures=new Map();
function hash(s){return crypto.createHash('sha256').update(s).digest();}
function same(a,b){return crypto.timingSafeEqual(hash(a),hash(b));}
function sign(p){return crypto.createHmac('sha256',sessionSecret).update(p).digest('base64url');}
function issueToken(role){const p=Buffer.from(JSON.stringify({role,exp:Date.now()+12*60*60*1000})).toString('base64url');return p+'.'+sign(p);}
function roleFromCookie(req){
 try{const token=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('asid='))?.slice(5)||'';
 const [p,h]=token.split('.');if(!p||!h||!same(sign(p),h))return null;
 const obj=JSON.parse(Buffer.from(p,'base64url').toString('utf8'));
 return obj.exp>Date.now()&&['admin','viewer'].includes(obj.role)?obj.role:null;
 }catch{return null;}
}
function headers(extra={}){return {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",...extra};}
function send(res,code,obj,extra={}){res.writeHead(code,headers({'Content-Type':'application/json; charset=utf-8',...extra}));res.end(JSON.stringify(obj));}
function fail(res,code,message){send(res,code,{error:message});}
function validOrigin(req){const origin=req.headers.origin;if(!origin)return true;try{
 const a=new URL(origin),host=req.headers['x-forwarded-host']||req.headers.host;
 return a.host===host && ['http:','https:'].includes(a.protocol);
 }catch{return false;}}
async function parseBody(req){return new Promise((resolve,reject)=>{let size=0,chunks=[];req.on('data',c=>{size+=c.length;if(size>3*1024*1024){reject(Object.assign(new Error('حجم البيانات يتجاوز 3MB'),{code:413}));req.destroy();}else chunks.push(c)});req.on('end',()=>{try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}'))}catch{reject(Object.assign(new Error('JSON غير صالح'),{code:400}));}});req.on('error',reject);});}
const depts=new Set(['الطوارئ','العيادات الخارجية','التنويم','العمليات الجراحية','الأشعة','المختبر','الصيدلية','العناية المركزة','المواعيد','خدمات المرضى','التغذية العلاجية','خدمات التمريض']);
const cats=new Set(['تأخر موعد','تأخر تقديم خدمة','الانتظار','الخطة العلاجية','صرف الأدوية','التواصل مع المريض','بيئة المستشفى']);
function bounded(x,n=200){return String(x??'').trim().slice(0,n)}
function dateValue(v){const v2=bounded(v,22);return /^20\d\d-\d\d-\d\d(?:[ T]\d\d:\d\d(?::\d\d)?)?$/.test(v2) && !Number.isNaN(Date.parse(v2.replace(' ','T')))?v2:'';}
function sanitizeSnapshot(input){
 if(!input||typeof input!=='object'||!Array.isArray(input.rows)||input.rows.length>15000)throw Error('عدد السجلات غير صالح');
 const rows=input.rows.map((v,i)=>{
  if(!v||typeof v!=='object')throw Error('سجل غير صالح في السطر '+i);
  const t=bounded(v.TicketNumber,28),title=bounded(v.Title,120),d=bounded(v['القسم المعني']||v['القسم'],100);
  if(!/^DEMO-\d{4,8}$/.test(t))throw Error('النسخة التجريبية تقبل سجلات DEMO فقط. ممنوع رفع بلاغات المرضى الحقيقية.');
  if(!cats.has(title)||!depts.has(d))throw Error('النسخة التجريبية تقبل الأقسام والتصنيفات التجريبية فقط.');
  const created=dateValue(v.CreatedOn),action=bounded(v.ActionDate,22)?dateValue(v.ActionDate):'';
  if(!created||(v.ActionDate&&!action))throw Error('تاريخ غير صالح');
  const assigned=bounded(v.AssignContact,50),closer=bounded(v['اغلق بواسطة'],50);
  if([assigned,closer].some(x=>x&&!/^موظف تجريبي \d{1,3}$/.test(x)))throw Error('يمكن حفظ أسماء الموظفين التجريبية فقط.');
  return {TicketNumber:t,Title:title,Division:'مستشفى عسير المركزي',CreatedOn:created,ActionDate:action,'القسم':d,'القسم المعني':d,'اغلق بواسطة':closer,AssignContact:assigned,HasResponse:v.HasResponse===true||v.HasResponse==='true',HasProcedure:v.HasProcedure===true||v.HasProcedure==='true'};
 });
 if(new Set(rows.map(r=>r.TicketNumber)).size!==rows.length)throw Error('أرقام البلاغات التجريبية مكررة');
 const plans=Array.isArray(input.plans)?input.plans.slice(0,200).map(p=>({
  department:depts.has(bounded(p.department,100))?bounded(p.department,100):'',
  problem:bounded(p.problem,240),action:bounded(p.action,240),
  owner:'مسؤول تجريبي',due:dateValue(p.due).slice(0,10),
  status:bounded(p.status,30),priority:bounded(p.priority,30)
 })):[];
 return {version:15,source:bounded(input.source,100)||'بيانات تجريبية',sourceCount:rows.length,
  lastUploaded:dateValue(input.lastUploaded)?input.lastUploaded:(new Date()).toISOString(),
  rows,plans,dateFrom:'',dateTo:'',logs:[],savedAt:new Date().toISOString()};
}
async function dbInit(){if(inMemory)return;await pool.query(`CREATE TABLE IF NOT EXISTS dashboard_state (id SMALLINT PRIMARY KEY CHECK (id=1), revision BIGINT NOT NULL, snapshot JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`);await pool.query(`INSERT INTO dashboard_state(id,revision,snapshot) VALUES(1,1,$1::jsonb) ON CONFLICT DO NOTHING`,[JSON.stringify(initial)]);}
async function dbGet(){if(inMemory)return current;const q=await pool.query('SELECT revision,snapshot FROM dashboard_state WHERE id=1');if(!q.rows.length)throw Error('Dashboard state missing');return {revision:Number(q.rows[0].revision),snapshot:q.rows[0].snapshot};}
async function dbPut(expected,snapshot){if(inMemory){if(expected!==current.revision)return null;current={revision:current.revision+1,snapshot};return current.revision;}
 const q=await pool.query('UPDATE dashboard_state SET revision=revision+1,snapshot=$1::jsonb,updated_at=now() WHERE id=1 AND revision=$2 RETURNING revision',[JSON.stringify(snapshot),expected]);return q.rows.length?Number(q.rows[0].revision):null;
}
async function handle(req,res){
 const url=new URL(req.url,'http://localhost');const route=url.pathname;
 if(req.method==='GET'&&route==='/health')return send(res,200,{status:'ok',mode:inMemory?'volatile-demo':'postgres'});
 if(route.startsWith('/api/')){
  if(['POST','PUT','PATCH','DELETE'].includes(req.method)&&!validOrigin(req))return fail(res,403,'طلب من مصدر غير موثوق');
  if(req.method==='POST'&&route==='/api/login'){
   const ip=(req.socket.remoteAddress||'').slice(0,80),record=loginFailures.get(ip)||{count:0,until:0};
   if(record.until>Date.now()&&record.count>=8)return fail(res,429,'محاولات كثيرة، انتظر 15 دقيقة');
   const body=await parseBody(req);const pass=String(body.password||'');
   if(pass.length>256)return fail(res,400,'كلمة مرور غير صالحة');
   const role=same(pass,adminPassword)?'admin':same(pass,viewerPassword)?'viewer':null;
   if(!role){record.count++;record.until=Date.now()+15*60*1000;loginFailures.set(ip,record);return fail(res,401,'كلمة المرور غير صحيحة');}
   loginFailures.delete(ip);
   return send(res,200,{role},{'Set-Cookie':`asid=${issueToken(role)}; Path=/; HttpOnly; ${inMemory?'':'Secure; '}SameSite=Lax; Max-Age=43200`});
  }
  if(req.method==='POST'&&route==='/api/logout')return send(res,200,{ok:true},{'Set-Cookie':`asid=; Path=/; HttpOnly; ${inMemory?'':'Secure; '}SameSite=Lax; Max-Age=0`});
  const role=roleFromCookie(req);if(!role)return fail(res,401,'يلزم تسجيل الدخول');
  if(req.method==='GET'&&route==='/api/session')return send(res,200,{role});
  if(req.method==='GET'&&route==='/api/state')return send(res,200,await dbGet());
  if(req.method==='POST'&&route==='/api/state'){
   if(role!=='admin')return fail(res,403,'لا تملك صلاحية التعديل');
   const body=await parseBody(req);const expected=body.revision;
   if(!Number.isInteger(expected)||expected<1)return fail(res,400,'رقم نسخة البيانات غير صالح');
   const next=sanitizeSnapshot(body.snapshot),revision=await dbPut(expected,next);
   if(revision===null)return fail(res,409,'توجد بيانات أحدث؛ حدث الصفحة ثم حاول مرة أخرى');
   return send(res,200,{revision});
  }
  return fail(res,404,'مسار غير معروف');
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return fail(res,405,'الطريقة غير مدعومة');
 if(route!=='/'&&route!=='/index.html')return fail(res,404,'الصفحة غير موجودة');
 const file=path.join(publicDir,'index.html');res.writeHead(200,headers({'Content-Type':'text/html; charset=utf-8'}));
 if(req.method==='HEAD')return res.end();fs.createReadStream(file).pipe(res);
}
async function main(){await dbInit();const server=http.createServer((req,res)=>{handle(req,res).catch(e=>{console.error('Request error:',e.message);if(!res.headersSent)fail(res,e.code||400, e.code?e.message:'تعذر تنفيذ الطلب');else res.end();});});server.listen(port,host,()=>console.log('Dashboard demo online',port,inMemory?'in-memory':'postgres'));}
main().catch(e=>{console.error('Startup failed',e.message);process.exit(1)});
